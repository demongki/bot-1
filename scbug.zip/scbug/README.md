<div align="center">
<img src="https://i.ibb.co/qCHNd0j/36fa310d84b9844bbea4eaf9d6462eed5d6127c6.jpg" alt="SELF-HX" width="300" />

# DAHLAH

>
>
>
</div>
<p align="center">
  <a href="https://github.com/Hexagonz"><img title="Author" src="https://img.shields.io/badge/Author-Hexagonz-red.svg?style=for-the-badge&logo=github" /></a>
  <h4 align="center">
  <a href="https://wa.me/6285751056816">KYAAA ONI CHAN >//< </a>
</h4>
</p>

## CARA INSTALL DI TERMUX
```bash
> pkg install nodejs && pkg install git
> git clone https://github.com/Hexagonz/SELF-HX
> cd SELF-HX
> bash install.sh
> npm start/node main.js
```
## CARA INSTALL DI LAPTOP
```bash
> git clone https://github.com/Hexagonz/SELF-HX 
> cd SELF-HX
> npm i
> npm start/node main.js
```

# INSTALL
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip)
* [Libwebp](https://developers.google.com/speed/webp/download)

# PIMTUR

| OWNER |✅|
| ------------- | ------------- |
| OFF |✅|
| ON |✅|
| STATUS |✅|

| MAKER |✅|
| ------------- | ------------- |
| STICKER |✅|
| STICKER GIF |✅|
| STICKER WM |✅|
| TAKE STICKER |✅|
| FDEFACE |✅|

| CONVERT |✅|
| ------------- | ------------- |
| TOIMG |✅|
| TOMP3 |✅|
| TOMP4 |✅|
| SLOW |✅|
| FAST |✅|
| REVERSE |✅|
| TOURL |✅|

| UP STORY |✅|
| ------------- | ------------- |
| UPSWTEXT |✅|
| UPSWIMAGE |✅|
| UPSWVIDEO  |✅|

| FUN |✅|
| ------------- | ------------- |
| FITNAH |✅|
| FITNAH PC |✅|
| KONTAK |✅|


| TAG |✅|
| ------------- | ------------- |
| STICKTAG |✅|
| HIDETAG |✅|
| KONTAG |✅|
| TOTAG |✅|

| DOWNLOAD |✅|
| ------------- | ------------- |
| YTSEARCH |✅|
| IGSTALK |✅|
| PLAY |✅|
| VIDEO |✅|
| YTMP3 |✅|
| YTMP4 |✅|
| IGDL |✅|
| FBDL |✅|
| TIKTOKDL |✅|
| TIKTOK AUDIO |✅|
| TWITTER |✅|
| BRAINLY |✅|
| IMAGE |✅|
| ANIME |✅|

| OTHER |✅|
| ------------- | ------------- |
| SELF |✅|
| PUBLIC |✅|
| SET THUMB |✅|
| SET FAKE IMG |✅|
| SET TARGET |✅|
| SET REPLY |✅|
| PING |✅|
| JOIN |✅|
| GET |✅|
| TERM |✅|
| X |✅|

  # MAKASIH LORT
* [`Baileys`](https://github.com/adiwajshing/Baileys)
* [`MhankBarBar`](https://github.com/MhankBarBar)
* [`MRHRTZ`](https://github.com/MRHRTZ)
  
  
