pkg install nodejs -y
npm install