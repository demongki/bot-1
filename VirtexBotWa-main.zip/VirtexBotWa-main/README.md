# Virtex Bot Whatsapp
Virtex BOT Whatsapp Ganas 2021

### UNTUK PENGGUNA TERMUX
```bash
> pkg update && pkg upgrade
> pkg install git -y
> pkg install nodejs -y
> git clone https://github.com/Bintang73/VirtexBotWa
> cd VirtexBotWa
> npm install
> node index.js
```

### UNTUK PENGGUNA WINDOWS/VPS/RDP
```bash
> download node js and install
> download git and install
> git clone https://github.com/Bintang73/VirtexBotWa
> cd VirtexBotWa
> npm install
> node index.js
```

### FILE UNTUK WINDOWS/VPS/RDP USER
* Download And Install Git [`Click Here`](https://git-scm.com/downloads) <br>
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download) <br>

###### BAGAIMANA CARA MENJALANKAN VIRTEX?
```bash
> setelah kamu membuat perintah "node index.js" lalu scan qr whatsapp web mu!
> cari target grup whatsapp
> kirim pesan "zhack" (tanpa tanda ")
> selamat virtex berhasil dikirim.
```

---------
###### CUSTUMASI PERINTAH DAN JAWABAN
```bash
> kamu juga bisa mencustom perintah dan jawaban bot kamu
> caranya kamu buka file setting.json
> lalu ubah kata "zhack" menjadi sesuka hati kalian.
> kamu juga bisa mengubah pesan "succes!" menjadi sesuka hati kalian.
```

---------

###### PERINGATAN!
```bash
> gunakan dengan bijak!
> apapun hasilnya bukan tanggung jawab kami!
> jika ada terbukti melanggar, saya tidak segan segan untuk menonaktifkan fitur ini.
> sekian, terimakasih.
```

---------

##### Powered By : [`st4rz`](https://instagram/bintang_nur_pradana) 
##### Donate : [`Saweria`](https://saweria.co/donate/bintangnurpradana) 
