<h1 align="center">そのメイキー <img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="40px" alt="hi"><br>SELFBOT</h1>

<p align="center">
<img src="https://i.ibb.co/ygjP0N0/b26c92fe495c.jpg" width="100%" alt="API Giphy logo"/>
</p>

- 🌱 I’m currently learning **nothing**.

- 👀 I m currently focusing on **JavaScript**.

- 📝 I m currently working on [`ShizukaAPIs`](https://api.shizukaa.xyz/) 

## Requirement

This repo require a [NodeJS](https://nodejs.org/) >= 11.15.0.

APIKEY [OnlyDevCity](https://wa.me/6281285627596)

## Termux Installation

First of all, you need to install [Git](https://git-scm.com/download/win) & [NodeJS](https://nodejs.org/). Then open your git bash, and follow this:<br>
```sh
$ termux-setup-storage
$ pkg install update && pkg install upgrade
$ pkg install ffmpeg && pkg install bash && pkg install nodejs
$ git clone https://github.com/ItsmeikyXSec4O4/SelfBotOdc/
$ cd VIRTEX-BOT-WA-ODC
$ ls
$ bash install.sh
$ node index.js

Tinggal Scan Dah :)

Cara Memanggil Nya Yaitu Dengan Ketik zhelp
```

## How to run

```sh
$ node index.js
```
or<br>
```sh
$ npm start
```

## PERATURAN!!

Ini Adalah Script Selfbot Jadi Hanya Untuk Owner Saja
Yang Bisa Akses Pada Menu Yang Ada Di Dalam Menu SelfBot 

◪ S&K !!
- ❏ Ganti Api Key Di Bagian lib/settings.json
- ❏ Dilarang Mengganti Nama Author / Team 
- ❏ Jika Ada Error Silahkan Hubungi Pembuat / Author Script Ini
- ❏ Sengaja Index Nya Saya Hash Karena Banyak Yang Ganti Nama Team :)
- ❏ Buy Api Key? Silahkan Kunjungin Web https://onlydevcity.herokuapp.com/


## Keyword

Type `zcreator` to see the creator
