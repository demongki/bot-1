let handler = m => m.reply('Wa`alaikumussalam')

handler.customPrefix = /mualaikum/i
handler.command = new RegExp

module.exports = handler