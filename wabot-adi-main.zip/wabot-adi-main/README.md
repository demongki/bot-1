# wabot-adi

Simpel WhatsApp Bot

## FOR DEPLOY HEROKU USER


<p><a href="https://heroku.com/deploy?template=https://github.com/Adi-OfficialL/wabot-adi"> <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy to Heroku" /></a></p>


## FOR TERMUX USER

```
> pkg update && pkg upgrade
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
> git clone https://github.com/Adi-OfficialL/wabot-adi
> cd wabot-adi
> npm install
> node adi.js
```

---------

## FOR WINDOWS/VPS/RDP USER

* Download And Install Git [`Click Here`](https://git-scm.com/downloads)
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download)
* Download And Install FFMPEG [`Click Here`](https://ffmpeg.org/download.html) (don't forget to path)
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php) (if nulis want work,  checklist columns 1,2,3,5,6)

```
> git clone https://github.com/Adi-OfficialL/wabot-adi
> cd wabot-adi
> npm install
```

---------

## Run

```bash
> node . [<session name>] (session name is optional)
```

#### Powered By : [`XTEAM`](https://api.xteam.xyz)

#### Author / Creator : [`Nurutomo`](https://GitHub.com/Nurutomo/wabot-aq)

#### Recode By : [`AdiOfficial`](https://youtube.com/channel/UCXzxFx9pitmYFLJo4nHrRPg)
