const donasi = (Ig, name) => { 
	return 
	 `     
             𝗗𝗢𝗡𝗔𝗦𝗜  

     *DONASI SEIKHLASNYA:)* 
 
  *BOT BY ${name}*




Note:
Jika Gamau Donasi Setidaknya Follow IG Ngab:D
Kalo Dah Donasi Silahkan Invit Di Group Kalian:)
Makasih:)

${Ig}

     `
}

exports.donasi = donasi